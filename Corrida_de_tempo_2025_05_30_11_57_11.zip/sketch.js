let xJogador = [0, 0, 0, 0];
let yJogador = [75, 150, 225, 300];
let jogador = ["🐶", "🐱", "🐰", "🐻"]; // Personagens
let teclas = ["9", "6", "3", "4"];
let quantidade = jogador.length;
let jogoAtivo = false;
let tempoRestante = 30; // 30 segundos
let timer;
let pontos = [0, 0, 0, 0]; // Array para contar os pontos dos jogadores
let venceu = [false, false, false, false]; // Array para controlar se o jogador já venceu

function setup() {
  createCanvas(400, 400);
  timer = setInterval(decrementaTempo, 1000); // Decrementa o tempo a cada segundo
}

function draw() {
  if (jogoAtivo) {
    ativaJogo();
    desenhaJogadores();
    desenhaLinhaDeChegada();
    verificaVencedor();
    exibeTempo();
  } else {
    exibeTelaInicial();
  }
}

function ativaJogo() {
  background("#655C4D");
}

function desenhaJogadores() {
  textSize(40);
  for (let i = 0; i < quantidade; i++) {
    text(jogador[i], xJogador[i], yJogador[i]);
  }
}

function desenhaLinhaDeChegada() {
  fill("white");
  rect(350, 0, 10, 400);
  fill("black");
  for (let yAtual = 0; yAtual < 400; yAtual += 20) {
    rect(350, yAtual, 10, 10);
  }
}

function verificaVencedor() {
  for (let i = 0; i < quantidade; i++) {
    if (xJogador[i] > 350 && !venceu[i]) {
      pontos[i]++; // Incrementa o ponto do jogador que venceu
      venceu[i] = true; // Marca que esse jogador já venceu uma vez
      text(jogador[i] + " cruzou a linha de chegada!", 50, 200);
      text("Pontuação: " + pontos.join(", "), 50, 250); // Mostra a pontuação de todos
    } else if (xJogador[i] <= 350) {
      venceu[i] = false; // Reseta a vitória se o jogador voltar para a esquerda
    }
  }
}

function keyReleased() {
  for (let i = 0; i < quantidade; i++) {
    if (key == teclas[i]) {
      xJogador[i] += random(20);
    }
  }
}

function exibeTelaInicial() {
  background("rgb(139,63,63)");
  textSize(32);
  fill("white");
  textAlign(CENTER);
  text("Pressione 'Enter' para começar!", width / 2, height / 2);
}

function keyPressed() {
  if (key === 'Enter') {
    jogoAtivo = true;
    xJogador = [0, 0, 0, 0]; // Reseta a posição dos jogadores
    tempoRestante = 30; // Reseta o tempo
    venceu = [false, false, false, false]; // Reseta o status de vitória
    loop(); // Inicia o loop do jogo
  }
}

function exibeTempo() {
  textSize(24);
  fill("black");
  text("Tempo restante: " + tempoRestante, 50, 30);
}

function decrementaTempo() {
  if (jogoAtivo) {
    tempoRestante--;
    if (tempoRestante <= 0) {
      jogoAtivo = false; // Para o jogo
      clearInterval(timer); // Para o temporizador
      exibeFimDeJogo(); // Chama a função para exibir o fim de jogo
    }
  }
}

function exibeFimDeJogo() {
  background("rgb(139,63,63)");
  textSize(32);
  fill("white");
  textAlign(CENTER);
  text("Fim de Jogo!", width / 2, height / 2 - 40);
  text("Pontuação final: " + pontos.join(", "), width / 2, height / 2 + 40);
}
